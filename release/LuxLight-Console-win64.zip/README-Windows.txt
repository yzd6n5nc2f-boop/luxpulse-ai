LuxLight Console (Windows)

1) Double-click LuxLight-Console.exe
2) The app starts local services and opens browser at http://127.0.0.1:5173
3) If browser does not open automatically, open that URL manually.

Notes:
- Input data is stored next to the .exe in: luxlight-runtime-data.json
- API health endpoint: http://127.0.0.1:4000/health
- Close the .exe window to stop services.
